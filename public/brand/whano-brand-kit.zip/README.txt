Whano brand kit
===============

App icon
- icon-512.png        512 x 512, transparent
- icon-192.png        192 x 192, transparent
- apple-touch-icon.png 180 x 180

Social card
- og.png              1200 x 630

Colors
- Deep teal  #066762  app icon
- Sand       #CA9F78  icon accent
- Ink        #16122B  type
- Green      #0B7A4B  actions
- Lilac      #E0D8FF  identity surface
- Mint       #CFF5DD  product surface

Typography
- Readex Pro, variable 160-700
- Wordmark: whano (lowercase)

Using the mark
- Keep clear space around the icon equal to one dot.
- Do not recolor, stretch, rotate, crop, or add effects.
- Do not use the mark as your own product mark or imply endorsement.

Whano is a Nomeda product.
Press and permissions: contact@nomeda.tech
